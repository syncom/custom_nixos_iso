// gcc -o hello_syncom hello_syncom.c
#include <stdio.h>

int main(void) {
    printf("hello syncom\n");
}
